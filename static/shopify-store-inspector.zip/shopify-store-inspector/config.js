// Where the inspector's API lives.
window.SSI_API = "http://127.0.0.1:8004";
