// Where the inspector's API lives.
window.SSI_API = "https://shopify-store-inspector.vercel.app";
